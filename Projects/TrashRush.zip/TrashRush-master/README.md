PROJECT TITLE: TrashRush

PURPOSE OF PROJECT: Teach people about the effects of climate change
  and what they can do to help though an interactive game that is 
  both educational and entertaining. This project was for my Writing
  class where we were required to create a multimodal project that 
  inspired people about climate change. While many students chose to
  make a simple poster or PowerPoint, I went above and beyon in 
  making an entire video game!
 
VERSION or DATE: Fall 2018

HOW TO START THIS PROJECT: java -cp ./Acme.jar:./objectdraw.jar:. TrashGame

AUTHORS: Jeromey Klein; I had some help from the Acme and objectdraw libraries

USER INSTRUCTIONS: Follow the instructions in the game and use the arrow keys 
  to navigate the introduction slides.
